import random

#used for storing usernames/passwords. do not push to github.
class LoginInfo(object):

  usernames = {}

  def __init__(self):
    self.usernames['gmail'] = 'oars.tests@2u.com' #used for logging into gmail
    self.usernames['email'] = 'oars.tests@2u.com' #used for logging into site; needs to be changed if app has been submitted
    self.usernames['password'] = 'Moodle1!'

  def get_login_info(self, key):
    return self.usernames[key]

  def random_username(self):
    self.usernames['email'] = 'oars.tests+'+str(random.choice(range(1000, 10000)))+'@2u.com' #used for new user creation